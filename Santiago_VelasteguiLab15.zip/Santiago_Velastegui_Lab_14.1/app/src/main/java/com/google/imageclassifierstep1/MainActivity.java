package com.google.imageclassifierstep1;

import android.app.Activity;

public class MainActivity extends Activity {
}
